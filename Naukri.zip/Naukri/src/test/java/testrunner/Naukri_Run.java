package testrunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;

@RunWith(io.cucumber.junit.Cucumber.class)
@CucumberOptions(features="C:\\Users\\Dell\\eclipse-workspace\\DemoMavenProject6\\Feature7\\Naukri.feature", glue= {"naukri_main"},



monochrome= true,
 

plugin= {"pretty" , "html:target/HtmlReports/cucumber.html",
                    "json:target/JSONReports/cucumber.json",
                    "junit:target/JUnitReports/cucumber.xml"}

)




public class Naukri_Run {

}
