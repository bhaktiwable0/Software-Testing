package Snapdeal;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Snapdeal_main {
	
	private BaseClass base;

	public Snapdeal_main(BaseClass base) throws InterruptedException {
		this.base = base;
		base.browserSetup();
		
	}

	public WebDriver driver;

	@Before(value = "@smoke1", order = 1)
	public void Login_User1_TC01() throws InterruptedException {
		
		base.driver.findElement(By.xpath("//input[@id='inputValEnter']")).sendKeys("Women Kurti");
		Thread.sleep(1000);
		System.out.println("search women Kurti sucessfully");
		
		base.driver.findElement(By.xpath("//span[@class='searchTextSpan']")).click();
		Thread.sleep(1000);
		System.out.println("click on search option sucessfully");
		
		base.driver.findElement(By.xpath("//img[@title=\"QPEEZ - Green Rayon Women's Flared Kurti ( Pack of 1 )\"]")).click();
		Thread.sleep(1000);
		System.out.println("click on Kurti sucessfully");
		
		String mainwindow = base.driver.getWindowHandle();
		 for(String beforwindow : base.driver.getWindowHandles()) {
			 base.driver.switchTo().window(beforwindow);
		 }
		 
		base.driver.findElement(By.xpath("//div[@id='add-cart-button-id']")).click();
		Thread.sleep(1000);
		System.out.println("Click On add to cart Option Successfully");
		
		base.driver.findElement(By.xpath("//div[@class='btn btn-theme-secondary open-cart']")).click();
		Thread.sleep(1000);
		System.out.println("Click On view cart Option Successfully");
		
		String mainwindow1 = base.driver.getWindowHandle();
		 Set<String> b = base.driver.getWindowHandles();
		 Iterator<String> i = b.iterator();
		 
		base.driver.findElement(By.xpath("//input[@id='pincode-value']")).sendKeys("411014");
		Thread.sleep(1000);
		System.out.println("Click On pincode-value Option Successfully");
		
		base.driver.findElement(By.xpath("//a[@id='send-pincode']")).click();
		Thread.sleep(1000);
		System.out.println("Click On send-pincode Option Successfully");
		
		 
		base.driver.findElement(By.xpath("//span[@class='remove-item-shortlist']")).click();
		Thread.sleep(1000);
		System.out.println("Click On remove-item Option Successfully");
		
		base.driver.findElement(By.xpath("//a[normalize-space()='START SHOPPING NOW']")).click();
		Thread.sleep(1000);
		System.out.println("Click On START SHOPPING NOW Option Successfully");
		
		base.driver.findElement(By.xpath("//div[@class='attr-val'][normalize-space()='M']")).click();
		Thread.sleep(1000);
		System.out.println("change in size Option Successfully");
		
		base.driver.navigate().refresh();
		
		base.driver.findElement(By.xpath("//div[@id='add-cart-button-id']")).click();
		Thread.sleep(1000);
		System.out.println("Click On add to cart Option Successfully");
		
		
		
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
		
		@Given("User Login Snapdeal page")
		public void User_Login_Snapdeal_page() {
			
		}

		@When("user enters valid username and password")
		public void user_enters_valid_username_and_password() {

		}

		@And("user clicks on login Button")
		public void user_clicks_on_login_Button() {

		}

		@Then("user is navigate to Home page DashBoard")
		public void user_is_navigate_to_Home_page_DashBoard() {
		
	}
	}



