package Snapdeal;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


public class BaseClass {
public String baseurl = "https://www.snapdeal.com/";


public WebDriver driver;

public void browserSetup() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Dell\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
    ChromeOptions options = new ChromeOptions();
    options.addArguments("--remote-allow-origins=*");
	
	driver = new ChromeDriver(options);
	
	
	driver.get(baseurl);
	driver.manage().window().maximize();
	driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	System.out.println("Browser Open");


}
}