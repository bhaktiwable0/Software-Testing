package basic_java;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Snapdeal_Interview {

	    WebDriver driver;
	
		@BeforeMethod

		public void webdriverLaunch() throws InterruptedException {

		System.setProperty("webdriver.driver.chrome", "C:\\Users\\Dell\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        
		driver = new ChromeDriver(options);

		driver.manage().window().maximize();
		
		driver.get("https://www.snapdeal.com/");

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		}
		
		@Test(priority = 0)
		public void TC01() throws Exception {
			
			driver.findElement(By.xpath("//input[@id='inputValEnter']")).sendKeys("Women Kurti");
			Thread.sleep(1000);
			System.out.println("search women Kurti sucessfully");
			
			driver.findElement(By.xpath("//span[@class='searchTextSpan']")).click();
			Thread.sleep(1000);
			System.out.println("click on search option sucessfully");
			
			driver.findElement(By.xpath("//img[@title=\"QPEEZ - Green Rayon Women's Flared Kurti ( Pack of 1 )\"]")).click();
			Thread.sleep(1000);
			System.out.println("click on Kurti sucessfully");
			
			String mainwindow = driver.getWindowHandle();
			 for(String beforwindow : driver.getWindowHandles()) {
				 driver.switchTo().window(beforwindow);
			 }
			 
			driver.findElement(By.xpath("//div[@id='add-cart-button-id']")).click();
			Thread.sleep(1000);
			System.out.println("Click On add to cart Option Successfully");
			
			driver.findElement(By.xpath("//div[@class='btn btn-theme-secondary open-cart']")).click();
			Thread.sleep(1000);
			System.out.println("Click On view cart Option Successfully");
			
			String mainwindow1 = driver.getWindowHandle();
			 Set<String> b = driver.getWindowHandles();
			 Iterator<String> i = b.iterator();
			 
			driver.findElement(By.xpath("//input[@id='pincode-value']")).sendKeys("411014");
			Thread.sleep(1000);
			System.out.println("Click On pincode-value Option Successfully");
			
			driver.findElement(By.xpath("//a[@id='send-pincode']")).click();
			Thread.sleep(1000);
			System.out.println("Click On send-pincode Option Successfully");
			
			 
			driver.findElement(By.xpath("//span[@class='remove-item-shortlist']")).click();
			Thread.sleep(1000);
			System.out.println("Click On remove-item Option Successfully");
			
			driver.findElement(By.xpath("//a[normalize-space()='START SHOPPING NOW']")).click();
			Thread.sleep(1000);
			System.out.println("Click On START SHOPPING NOW Option Successfully");
			
			driver.findElement(By.xpath("//div[@class='attr-val'][normalize-space()='M']")).click();
			Thread.sleep(1000);
			System.out.println("change in size Option Successfully");
			
			driver.navigate().refresh();
			
			driver.findElement(By.xpath("//div[@id='add-cart-button-id']")).click();
			Thread.sleep(1000);
			System.out.println("Click On add to cart Option Successfully");
			
		
		
		
		
		
		
		
		}

}


