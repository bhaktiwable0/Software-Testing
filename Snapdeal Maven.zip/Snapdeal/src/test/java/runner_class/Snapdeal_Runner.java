package runner_class;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;

@RunWith(io.cucumber.junit.Cucumber.class)
@CucumberOptions(features="C:\\Users\\Dell\\eclipse-workspace\\Snapdeal\\src\\test\\java\\Feature20\\snapdeal.feature", glue= {"Snapdeal"},



monochrome= true,
 
 
plugin= {"pretty" , "html:target/HtmlReports/cucumber.html",
                    "json:target/JSONReports/cucumber.json",
                    "junit:target/JUnitReports/cucumber.xml"}

)



public class Snapdeal_Runner {

}
