package naukri_main;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Naukri_Login {

	public WebDriver driver;

	@Before(order = 0)
	public void browserSetup() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Dell\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
	    options.addArguments("--remote-allow-origins=*");
		
		driver = new ChromeDriver(options);
		driver.get("https://www.naukri.com/");

		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Browser Open");

	}

	@Before(value = "@smoke1", order = 1)
	public void Login_User1_TC01() throws InterruptedException {
		driver.findElement(By.xpath("//a[@id='login_Layer']")).click();
		Thread.sleep(1000);
		System.out.println("click on login option successfully");
		
		driver.findElement(By.xpath("//input[@placeholder='Enter your active Email ID / Username']")).sendKeys("bhaktiwable0@gmail.com");
		Thread.sleep(1000);
		System.out.println("click on username successfully");

		driver.findElement(By.xpath("//input[@placeholder='Enter your password']")).sendKeys("bhakti01");
		Thread.sleep(1000);
		System.out.println("click on password successfully");

		driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		Thread.sleep(1000);
		System.out.println("click on login button successfully");
		
		driver.findElement(By.xpath("//img[@alt='naukri user profile img']")).click();
		Thread.sleep(1000);
		System.out.println("click on profile successfully");
		
		driver.findElement(By.xpath("//a[normalize-space()='Logout']")).click();
		Thread.sleep(1000);
		System.out.println("click on logout option successfully");

		
	
}
	
	@Given("User Login naukri login page")
	public void User_Login_naukri_login_page() {
	}

	@When("user enters valid username and password")
	public void user_enters_valid_username_and_password() {

	}

	@And("user clicks on login Button")
	public void user_clicks_on_login_Button() {

	}

	@Then("user is navigate to Home page DashBoard")
	public void user_is_navigate_to_Home_page_DashBoard() {

	}

}
